import { defineConfig } from "vite";
import react from "@vitejs/plugin-react";
import tailwindcss from "@tailwindcss/vite";

export default defineConfig({
  plugins: [tailwindcss(), react()],
  server: {
    port: 5173,
    open: false,
    proxy: {
      "/media": {
        target: "http://localhost:8000",
        changeOrigin: true,
      },
    },
  }
});

