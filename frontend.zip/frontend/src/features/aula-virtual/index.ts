export { AulaVirtualApp } from "./AulaVirtualApp";
