export { VinculacionCurricularPage } from "./VinculacionCurricularPage";
