// Este código define un cliente API genérico para interactuar con un backend RESTful en una aplicación frontend.
// Proporciona funciones para realizar solicitudes GET, POST, PUT, PATCH y DELETE, y maneja la construcción de rutas y el manejo de errores.
import { BackendModule } from "../types/module";

const API_BASE_URL = import.meta.env.VITE_API_BASE_URL ?? "http://localhost:8000/api";

export const TOKEN_KEY = "siged_token";

export function getApiBaseUrl(): string {
  return API_BASE_URL;
}

export function getAuthToken(): string | null {
  return localStorage.getItem(TOKEN_KEY);
}

type RequestOptions = {
  signal?: AbortSignal;
  headers?: HeadersInit;
};

function getAuthHeaders(): HeadersInit {
  const token = localStorage.getItem(TOKEN_KEY);
  if (token) {
    return { Authorization: `Bearer ${token}` };
  }
  return {};
}

/**
 * Utilidad para construir la ruta base de un módulo con su barra inclinada correspondiente.
 * Ej: buildModulePath("ubicacion", "paises") -> "/ubicacion/paises/"
 */
export const buildModulePath = (module: BackendModule, endpoint: string): string => {
  return `/${module}/${endpoint}/`;
};

// --- FUNCIÓN GET ---
export async function apiGet<TResponse>(
  path: string,
  options: RequestOptions = {}
): Promise<TResponse> {
  const response = await fetch(`${API_BASE_URL}${path}`, {
    method: "GET",
    headers: {
      Accept: "application/json",
      ...getAuthHeaders(),
      ...options.headers
    },
    signal: options.signal
  });

  if (response.status === 401) {
    localStorage.removeItem(TOKEN_KEY);
    localStorage.removeItem("siged_usuario");
    window.location.reload();
    throw new Error("Sesión expirada");
  }

  if (!response.ok) {
    throw new Error(`Error ${response.status} consultando ${path}`);
  }

  return response.json() as Promise<TResponse>;
}

// --- FUNCIÓN POST ---
export async function apiPost<TBody, TResponse>(
  path: string,
  body: TBody,
  options: RequestOptions = {}
): Promise<TResponse> {
  const response = await fetch(`${API_BASE_URL}${path}`, {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      Accept: "application/json",
      ...getAuthHeaders(),
      ...options.headers
    },
    body: JSON.stringify(body),
    signal: options.signal
  });

  if (response.status === 401) {
    localStorage.removeItem(TOKEN_KEY);
    localStorage.removeItem("siged_usuario");
    window.location.reload();
    throw new Error("Sesión expirada");
  }

  if (!response.ok) {
    const errorData = await response.json().catch(() => ({}));
    const error = new Error(`Error ${response.status} registrando en ${path}`) as any;
    error.data = errorData;
    throw error;
  }

  return response.json() as Promise<TResponse>;
}

// --- NUEVA FUNCIÓN PUT (Actualización Completa) ---
export async function apiPut<TBody, TResponse>(
  path: string,
  body: TBody,
  options: RequestOptions = {}
): Promise<TResponse> {
  const response = await fetch(`${API_BASE_URL}${path}`, {
    method: "PUT",
    headers: {
      "Content-Type": "application/json",
      Accept: "application/json",
      ...getAuthHeaders(),
      ...options.headers
    },
    body: JSON.stringify(body),
    signal: options.signal
  });

  if (response.status === 401) {
    localStorage.removeItem(TOKEN_KEY);
    localStorage.removeItem("siged_usuario");
    window.location.reload();
    throw new Error("Sesión expirada");
  }

  if (!response.ok) {
    // Capturamos errores de validación (ej. Django REST Framework 400 Bad Request)
    const errorData = await response.json().catch(() => ({}));
    const error = new Error(`Error ${response.status} reemplazando en ${path}`) as any;
    error.data = errorData;
    throw error;
  }

  return response.json() as Promise<TResponse>;
}

// --- NUEVA FUNCIÓN PATCH (Actualización Parcial) ---
export async function apiPatch<TBody, TResponse>(
  path: string,
  body: Partial<TBody>, // Partial permite enviar solo las propiedades que cambian
  options: RequestOptions = {}
): Promise<TResponse> {
  const response = await fetch(`${API_BASE_URL}${path}`, {
    method: "PATCH",
    headers: {
      "Content-Type": "application/json",
      Accept: "application/json",
      ...getAuthHeaders(),
      ...options.headers
    },
    body: JSON.stringify(body),
    signal: options.signal
  });

  if (response.status === 401) {
    localStorage.removeItem(TOKEN_KEY);
    localStorage.removeItem("siged_usuario");
    window.location.reload();
    throw new Error("Sesión expirada");
  }

  if (!response.ok) {
    // Capturamos errores de validación
    const errorData = await response.json().catch(() => ({}));
    const error = new Error(`Error ${response.status} modificando en ${path}`) as any;
    error.data = errorData;
    throw error;
  }

  return response.json() as Promise<TResponse>;
}

// --- FUNCIÓN UPLOAD (multipart/form-data) ---
export async function apiUpload<TResponse>(
  path: string,
  formData: FormData,
  options: RequestOptions = {}
): Promise<TResponse> {
  const response = await fetch(`${API_BASE_URL}${path}`, {
    method: "POST",
    headers: {
      Accept: "application/json",
      ...getAuthHeaders(),
      ...options.headers
    },
    body: formData,
    signal: options.signal
  });

  if (response.status === 401) {
    localStorage.removeItem(TOKEN_KEY);
    localStorage.removeItem("siged_usuario");
    window.location.reload();
    throw new Error("Sesión expirada");
  }

  if (!response.ok) {
    const errorData = await response.json().catch(() => ({}));
    const error = new Error(`Error ${response.status} subiendo archivo en ${path}`) as any;
    error.data = errorData;
    throw error;
  }

  return response.json() as Promise<TResponse>;
}

// --- FUNCIÓN UPLOAD PATCH (multipart/form-data, método PATCH) ---
export async function apiUploadPatch<TResponse>(
  path: string,
  formData: FormData,
  options: RequestOptions = {}
): Promise<TResponse> {
  const response = await fetch(`${API_BASE_URL}${path}`, {
    method: "PATCH",
    headers: {
      Accept: "application/json",
      ...getAuthHeaders(),
      ...options.headers
    },
    body: formData,
    signal: options.signal
  });

  if (response.status === 401) {
    localStorage.removeItem(TOKEN_KEY);
    localStorage.removeItem("siged_usuario");
    window.location.reload();
    throw new Error("Sesión expirada");
  }

  if (!response.ok) {
    const errorData = await response.json().catch(() => ({}));
    const error = new Error(`Error ${response.status} actualizando archivo en ${path}`) as any;
    error.data = errorData;
    throw error;
  }

  return response.json() as Promise<TResponse>;
}

// --- FUNCIÓN DELETE ---
export async function apiDelete<TResponse = void>(
  path: string,
  options: RequestOptions = {}
): Promise<TResponse> {
  const response = await fetch(`${API_BASE_URL}${path}`, {
    method: "DELETE",
    headers: {
      ...getAuthHeaders(),
      ...options.headers
    },
    signal: options.signal
  });

  if (response.status === 401) {
    localStorage.removeItem(TOKEN_KEY);
    localStorage.removeItem("siged_usuario");
    window.location.reload();
    throw new Error("Sesión expirada");
  }

  if (!response.ok) {
    throw new Error(`Error ${response.status} eliminando en ${path}`);
  }

  if (response.status === 204) {
    return {} as TResponse;
  }

  return response.json() as Promise<TResponse>;
}