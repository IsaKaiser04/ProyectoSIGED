﻿from django.urls import path, include
from rest_framework.routers import DefaultRouter

# Importaciones nuevas (Patrón ViewSet)
from .views.anio_lectivo_view import AnioLectivoViewSet
from .views.paralelo_view import ParaleloViewSet

# Importaciones antiguas (Las que no hemos tocado aún)
from .views.plan_estudio_view import PlanEstudioListCreateView, PlanEstudioDetailView, GradoListCreateView, GradoDetailView, AsignaturaListCreateView, AsignaturaDetailView
from .views.calificacion_view import CalificacionListCreateView, CalificacionDetailView
from .views.oferta_view import OfertaAcademicaListCreateView, OfertaAcademicaDetailView, GradoOfertadoListCreateView, GradoOfertadoDetailView, AsignaturaOfertadaListCreateView, AsignaturaOfertadaDetailView
from .views.educacion_view import NivelEducativoListView

router = DefaultRouter()
router.register(r'anios-lectivos', AnioLectivoViewSet, basename='anio-lectivo')
router.register(r'paralelos', ParaleloViewSet, basename='paralelo')

urlpatterns = [
    # Rutas nuevas con patrón correcto
    path('', include(router.urls)),

    # Rutas antiguas (Mantenidas por compatibilidad temporal con otros módulos)
    path('planes-estudio/', PlanEstudioListCreateView.as_view(), name='planestudio-list-create'),
    path('planes-estudio/<int:pk>/', PlanEstudioDetailView.as_view(), name='planestudio-detail'),
    path('grados/', GradoListCreateView.as_view(), name='grado-list-create'),
    path('grados/<int:pk>/', GradoDetailView.as_view(), name='grado-detail'),
    path('asignaturas/', AsignaturaListCreateView.as_view(), name='asignatura-list-create'),
    path('asignaturas/<int:pk>/', AsignaturaDetailView.as_view(), name='asignatura-detail'),
    path('calificaciones/', CalificacionListCreateView.as_view(), name='calificacion-list-create'),
    path('calificaciones/<int:pk>/', CalificacionDetailView.as_view(), name='calificacion-detail'),
    path('oferta/', OfertaAcademicaListCreateView.as_view(), name='oferta-list-create'),
    path('oferta/<int:pk>/', OfertaAcademicaDetailView.as_view(), name='oferta-detail'),
    path('grados-ofertados/', GradoOfertadoListCreateView.as_view(), name='gradoofertado-list-create'),
    path('grados-ofertados/<int:pk>/', GradoOfertadoDetailView.as_view(), name='gradoofertado-detail'),
    path('niveles/', NivelEducativoListView.as_view(), name='nivel-educativo-list'),
    path('asignaturas-ofertadas/', AsignaturaOfertadaListCreateView.as_view(), name='asignaturaofertada-list-create'),
    path('asignaturas-ofertadas/<int:pk>/', AsignaturaOfertadaDetailView.as_view(), name='asignaturaofertada-detail'),
]
