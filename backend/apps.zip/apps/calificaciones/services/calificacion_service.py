from decimal import Decimal
from django.db import transaction
from django.utils import timezone

from apps.calificaciones.models.calificacion import Calificacion
from apps.calificaciones.models.calificacionHistorico import CalificacionHistorico
from apps.calificaciones.models.promedio import Promedio
from apps.calificaciones.models.promedioCategoria import PromedioCategoria


class CalificacionService:

    @transaction.atomic
    def registrar_calificacion(self, asignatura_evaluacion, matricula, valor, observacion='', promedio_categoria=None):
        calificacion, created = Calificacion.objects.update_or_create(
            asignatura_evaluacion=asignatura_evaluacion,
            matricula=matricula,
            defaults={
                'valor': valor,
                'observacion': observacion,
                'promedio_categoria': promedio_categoria,
            },
        )
        if not created:
            self._guardar_historico(calificacion, valor, observacion)
        return calificacion, created

    @transaction.atomic
    def actualizar_calificacion(self, calificacion_id, valor, observacion=''):
        try:
            calificacion = Calificacion.objects.select_for_update().get(id=calificacion_id)
        except Calificacion.DoesNotExist:
            return None
        self._guardar_historico(calificacion, valor, observacion)
        calificacion.valor = valor
        calificacion.observacion = observacion
        calificacion.save()
        return calificacion

    def _guardar_historico(self, calificacion, valor_nuevo, observacion=''):
        if calificacion.valor != valor_nuevo:
            CalificacionHistorico.objects.create(
                valor_anterior=calificacion.valor,
                valor_nuevo=valor_nuevo,
                observacion=observacion or calificacion.observacion,
                calificacion=calificacion,
            )

    def calcular_promedio(self, calificaciones):
        if not calificaciones:
            return Decimal('0.00')
        total = sum(c.valor for c in calificaciones)
        return (total / len(calificaciones)).quantize(Decimal('0.01'))

    def calcular_equivalencia(self, valor, rubrica=None):
        if not rubrica:
            return ''
        equivalencia = rubrica.equivalencias.filter(
            evaluacioncriterio__cuantitativaMinima__lte=valor,
            evaluacioncriterio__cuantitativaMaxima__gte=valor,
        ).first()
        if equivalencia:
            criterio = equivalencia.criterios.filter(
                cuantitativaMinima__lte=valor,
                cuantitativaMaxima__gte=valor,
            ).first()
            return criterio.cualitativa if criterio else equivalencia.nombre
        return ''

    def calcular_estado_final(self, promedio, nota_minima_aprobacion=Decimal('7.00')):
        return 'APROBADO' if promedio >= nota_minima_aprobacion else 'REPROBADO'
from decimal import Decimal, InvalidOperation

from django.db import transaction
from rest_framework.exceptions import NotFound, ValidationError

from apps.calificaciones.models.asignaturaEvaluacion import AsignaturaEvaluacion
from apps.calificaciones.models.calificacion import Calificacion
from apps.calificaciones.models.calificacionHistorico import CalificacionHistorico
from apps.calificaciones.models.tipoCalculo import TipoCalculo
from apps.calificaciones.repositories.matriz_repository import MatrizRepository
from apps.calificaciones.services.periodo_service import PeriodoService
from apps.calificaciones.services.promedio_service import (
    NOTA_MINIMA_APROBACION,
    TOLERANCIA_PESOS,
    PromedioService,
)


class CalificacionService:

    def __init__(self, repository=None):
        self.repo = repository or MatrizRepository()

    # ------------------------------------------------------------------ #
    # Actividades
    # ------------------------------------------------------------------ #
    @transaction.atomic
    def crear_actividad(self, docente, distributivo_asignatura_id, nombre, fecha_entrega,
                        descripcion='', tipo_calculo=TipoCalculo.SIMPLE, peso=None):
        """
        Regla 1: la asignatura debe ser del docente.
        Regla 2: el período se asigna solo, según fecha_entrega (400 si no existe).
        Regla 5: si ese período ya cerró -> 403.
        """
        da = self.repo.obtener_asignatura_del_docente(docente, distributivo_asignatura_id)
        if da is None:
            raise NotFound('Asignatura no encontrada en tu distributivo.')

        periodo = PeriodoService.asignar_periodo(da, fecha_entrega)
        PeriodoService.validar_periodo_abierto(periodo)

        peso = self._normalizar_peso(tipo_calculo, peso)
        self._validar_coherencia_periodo(da, periodo, tipo_calculo, peso)

        return AsignaturaEvaluacion.objects.create(
            nombre=nombre,
            descripcion=descripcion,
            fecha_entrega=fecha_entrega,
            tipo_calculo=tipo_calculo,
            peso=peso,
            distributivo_asignatura=da,
            periodo_academico=periodo,
        )

    @staticmethod
    def _normalizar_peso(tipo_calculo, peso):
        if tipo_calculo == TipoCalculo.SIMPLE:
            return None
        if tipo_calculo != TipoCalculo.PONDERADO:
            raise ValidationError({'tipo_calculo': 'Debe ser SIMPLE o PONDERADO.'})
        if peso is None:
            raise ValidationError({'peso': 'Una actividad ponderada requiere peso.'})
        try:
            peso = Decimal(str(peso))
        except InvalidOperation:
            raise ValidationError({'peso': 'Peso inválido.'})
        if not (Decimal('0') < peso <= Decimal('1')):
            raise ValidationError({'peso': 'El peso debe ser una fracción entre 0 y 1 (0.30 = 30 %).'})
        return peso

    @staticmethod
    def _validar_coherencia_periodo(da, periodo, tipo_calculo, peso, excluir_id=None):
        existentes = AsignaturaEvaluacion.objects.filter(
            distributivo_asignatura=da, periodo_academico=periodo, activo=True,
        )
        if excluir_id:
            existentes = existentes.exclude(pk=excluir_id)
        existentes = list(existentes)
        if not existentes:
            return
        if any(a.tipo_calculo != tipo_calculo for a in existentes):
            raise ValidationError({
                'tipo_calculo': f'El período "{periodo.nombre}" ya usa cálculo '
                                f'{existentes[0].tipo_calculo}; no se puede mezclar.'
            })
        if tipo_calculo == TipoCalculo.PONDERADO:
            suma = sum((a.peso or Decimal('0') for a in existentes), Decimal('0')) + peso
            if suma - Decimal('1') > TOLERANCIA_PESOS:
                raise ValidationError({
                    'peso': f'Los pesos del período sumarían {suma * 100:.2f} %; el máximo es 100 %.'
                })

    # ------------------------------------------------------------------ #
    # Notas
    # ------------------------------------------------------------------ #
    @transaction.atomic
    def registrar_nota(self, docente, actividad_id, matricula_id, valor, observacion=''):
        """
        Crea o actualiza la nota de un estudiante. El docente envía SOLO el número;
        la cualitativa se deriva al leer (regla 6).
        """
        actividad = (
            AsignaturaEvaluacion.objects
            .select_related('distributivo_asignatura__distributivo', 'periodo_academico')
            .filter(pk=actividad_id, distributivo_asignatura__distributivo__docente=docente)  # regla 1
            .first()
        )
        if actividad is None:
            raise NotFound('Actividad no encontrada en tu distributivo.')

        PeriodoService.validar_periodo_abierto(actividad.periodo_academico)       # regla 5

        da = actividad.distributivo_asignatura
        matricula = self.repo.matriculas_del_curso(da).filter(pk=matricula_id).first()
        if matricula is None:
            raise ValidationError({'matricula': 'El estudiante no pertenece a este curso.'})

        valor = self._validar_valor(valor)

        calificacion = (
            Calificacion.objects.select_for_update()
            .filter(asignatura_evaluacion=actividad, matricula=matricula)
            .first()
        )
        if calificacion is None:
            calificacion = Calificacion.objects.create(
                asignatura_evaluacion=actividad, matricula=matricula,
                valor=valor, observacion=observacion,
            )
        else:
            # El histórico se guarda ANTES de sobrescribir (el servicio anterior lo hacía
            # después, comparaba valor contra sí mismo y nunca registraba nada).
            self._guardar_historico(calificacion, valor, observacion)
            calificacion.valor = valor
            calificacion.observacion = observacion
            calificacion.save()

        PromedioService.persistir_promedio_periodo(matricula, da, actividad.periodo_academico)
        return calificacion

    @staticmethod
    def _validar_valor(valor):
        try:
            valor = Decimal(str(valor)).quantize(Decimal('0.01'))
        except (InvalidOperation, ValueError):
            raise ValidationError({'valor': 'La nota debe ser numérica.'})
        if not (Decimal('0') <= valor <= Decimal('10')):
            raise ValidationError({'valor': 'La nota debe estar entre 0 y 10.'})
        return valor

    @staticmethod
    def _guardar_historico(calificacion, valor_nuevo, observacion=''):
        if calificacion.valor != valor_nuevo:
            CalificacionHistorico.objects.create(
                calificacion=calificacion,
                valor_anterior=calificacion.valor,
                valor_nuevo=valor_nuevo,
                observacion=observacion or calificacion.observacion,
            )

    # Se conserva: lo usan calificacion_view.py (legacy) y tests.py
    def calcular_estado_final(self, promedio, nota_minima_aprobacion=NOTA_MINIMA_APROBACION):
        return 'APROBADO' if promedio >= nota_minima_aprobacion else 'REPROBADO'